#!/bin/bash
echo "Starting Fleeman Frontend..."
echo ""
echo "Installing dependencies..."
npm install
echo ""
echo "Starting Next.js development server..."
npm run dev 